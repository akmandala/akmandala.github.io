var app = require('http').createServer(handler);
//var url= require('/home/pi/node_modules/url');
var url= require('url');
var fs = require('fs');
var inLoop = false;
// Http handler function
function handler (req, res) {
    
    // Using URL to parse the requested URL
    var path = url.parse(req.url).pathname;
    
    // Managing the root route
    if (path == '/') {
        index = fs.readFile(__dirname+'/monohud.html', 
		//index = fs.readFile(__dirname+'/three.html', 
            function(error,data) {
                
                if (error) {
                    res.writeHead(500);
                    return res.end("Error: unable to load three.html");
                }
                
                res.writeHead(200,{'Content-Type': 'text/html'});
                res.end(data);
            });

    // Managing the route for the javascript files
    } else if( /\.(mp4)$/.test(path) ) {
        index = fs.readFile(__dirname+path, 
            function(error,data) {
                
                if (error) {
                    res.writeHead(500);
                    return res.end("Error: unable to load " + path);
                }
                
                res.writeHead(200,{'Content-Type': 'text/plain'});
                res.end(data);
            });
    } else if( /\.(js)$/.test(path) ) {
        index = fs.readFile(__dirname+path, 
            function(error,data) {
                
                if (error) {
                    res.writeHead(500);
                    return res.end("Error: unable to load " + path);
                }
                
                res.writeHead(200,{'Content-Type': 'text/plain'});
                res.end(data);
            });
    } else {
        res.writeHead(404);
        res.end("Error: 404 - File not found.");
    }
}
app.listen(9000);
// OBD reader and emitter to the browser
//var io = require('/home/pi/node_modules/socket.io').listen(app);
var io = require('socket.io').listen(app);

//setInterval (function() {	
//	io.sockets.emit('serial', '1234,47,15');		
//}, 500);

var net = require('net');
var obd = new net.Socket();

var inLoop = false;
var intervalConnect = false;

function connect() {
    obd.connect({
        port: 35000,
        host: '192.168.0.10'
    })
}

function launchIntervalConnect() {
    if(false != intervalConnect) return
    intervalConnect = setInterval(connect, 1000)
}

function clearIntervalConnect() {
    if(false == intervalConnect) return
    clearInterval(intervalConnect)
    intervalConnect = false
}

obd.on('connect', () => {
    clearIntervalConnect()
	console.log('Connected')
	obd.write('ATZ\r')		// Reset OBD
	setTimeout(function() {		// Wait for 1sec, then send request..
		obd.write('010C\r')
	}, 1000)
	setTimeout(function() {		// Wait for 2sec, then send real request to be read
		obd.write('010C\r')
		inLoop = true
	}, 3000)
})

obd.on('error', (err) => {
    console.log('OBD Error')
    launchIntervalConnect()
})

obd.on('close', launchIntervalConnect)
obd.on('end', launchIntervalConnect)

connect()

var rpm = '100';
var temp = '25';
var speed = '10';
var gear = 2.5;
var gearTable=[0.6, 0.9, 1.3, 1.9, 2.5, 3.2];
var gearNumber =[0,0,0,0];

obd.on('data', function(data) {
	data = data.toString();
	//console.log(data);
	
	if ((inLoop) && (data.length>4)) {
		if (inLoop == 1) {
			var pos = data.indexOf('41 0C ');
			data = data.slice(pos+6,pos+11);
			//console.log('split: ' + data);
			rpm = (((parseInt(data.slice(0, 2),16) * 256) + parseInt(data.slice(3, 4),16)) >> 2).toString();
			console.log('RPM: ' + rpm);
			setTimeout(function() {	
				obd.write('0105\r');
				inLoop += 1;
			}, 100);
		} else if (inLoop == 2) {
			var pos = data.indexOf('41 05 ');
			data = data.slice(pos+6,pos+8);
			//console.log('split: ' + data);
			temp = (parseInt(data.slice(0, 2),16) - 40).toString();
			console.log('Temp: ' + temp);
			setTimeout(function() {	
				obd.write('010D\r');
				inLoop += 1;
			}, 100);
		} else if (inLoop == 3) {
			var pos = data.indexOf('41 0D ');
			data = data.slice(pos+6,pos+8);
			//console.log('split: ' + data);
			speed = (parseInt(data.slice(0, 2),16)).toString();
			console.log('Speed: ' + speed);
			gear =  parseInt(speed,10) / (parseInt(rpm,10) / 100.0);
			if (gear<gearTable[0]) {
				gear = 0;
			} else if ((gear>gearTable[0]) && (gear<gearTable[1])) {
				gear = 1;
			} else if ((gear>gearTable[1]) && (gear<gearTable[2])) {
				gear = 2;
			} else if ((gear>gearTable[2]) && (gear<gearTable[3])) {
				gear = 3;
			} else if ((gear>gearTable[3]) && (gear<gearTable[4])) {
				gear = 4;
			} else if ((gear>gearTable[4]) && (gear<gearTable[5])) {
				gear = 5;
			} else if (gear>gearTable[5]) {
				gear = 6;
			}
			gearNumber[2] = gearNumber[1];
			gearNumber[1] = gearNumber[0];
			gearNumber[0] = gear.toFixed();
			if ((gearNumber[2]==gearNumber[1]) && (gearNumber[1]==gearNumber[0])) {
				gearNumber[3] = gearNumber[1];
				//console.log('Gear: ' + gearNumber[3]);
			}
			io.sockets.emit('serial', rpm + ',' + temp + ',' + speed + ',' + gearNumber[3].toString());
			//sendObd(rpm + ',' + temp + ',' + speed + ',' + gearNumber[3].toString());
			setTimeout(function() {	
				obd.write('010C\r');
				inLoop = 1;
			}, 100);
		}
	}
});

obd.on('close', function() {
	console.log('Connection closed');
});